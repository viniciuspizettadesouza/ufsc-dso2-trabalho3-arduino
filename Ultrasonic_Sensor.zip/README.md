# dso2-trabalho3-arduino
Enviando dados de sensor ultrassônico conectado no Arduino, através de requisições http
