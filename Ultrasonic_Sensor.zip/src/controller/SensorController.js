module.exports = {

  async store(req, res) {
    // const newSensor = await Sensor.create(req.body);
    // return res.status(200).send({ newSensor });
    console.log(req)
  }
}